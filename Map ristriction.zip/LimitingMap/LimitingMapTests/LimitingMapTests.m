//
//  LimitingMapTests.m
//  LimitingMapTests
//
//  Created by Vladimir Kolbas on 18/01/14.
//  Copyright (c) 2014 Vladimir Kolbas. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface LimitingMapTests : XCTestCase

@end

@implementation LimitingMapTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
