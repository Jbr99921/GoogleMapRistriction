//
//  ViewController.h
//  LimitingMap
//
//  Created by Vladimir Kolbas on 18/01/14.
//  Copyright (c) 2014 Vladimir Kolbas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
