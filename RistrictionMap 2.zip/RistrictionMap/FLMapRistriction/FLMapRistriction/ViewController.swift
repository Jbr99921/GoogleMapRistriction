//
//  ViewController.swift
//  FLMapRistriction
//
//  Created by Appleto on 10/06/20.
//  Copyright © 2020 Appleto. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlaces

class ViewController: UIViewController,GMSMapViewDelegate{

    @IBOutlet weak var MapView: GMSMapView!
   
      var leftLong:Double? = nil
      var rightLong:Double? = nil
      var bottomLat:Double? = nil
      var topLat:Double? = nil
    
      var center:CLLocationCoordinate2D?
      var topLeft:CLLocationCoordinate2D?
      var topRight: CLLocationCoordinate2D?
      var bottomLeft:CLLocationCoordinate2D?
      var bottomRight:CLLocationCoordinate2D?
        
      var currentPosition:GMSMarker? = nil
        
    override func viewDidLoad() {
        super.viewDidLoad()
    
     self.MapView.delegate = self;
       
        leftLong = 70.0;
        rightLong = 71.0;
        bottomLat  = 23.0;
        topLat  = 24.0;
        
        center = CLLocationCoordinate2DMake(70.895064, 23.858220)

        let camera = GMSCameraPosition.camera(withLatitude: (center!.latitude), longitude: (center!.longitude), zoom: 10)
        MapView.setMinZoom(7, maxZoom: 15)
        MapView.isUserInteractionEnabled = true
        MapView.camera = camera
        currentPosition = GMSMarker(position: center!)
        currentPosition?.map = self.MapView
               
        topLeft     = CLLocationCoordinate2DMake(topLat!, leftLong!)
        topRight    = CLLocationCoordinate2DMake(topLat!, rightLong!)
        bottomRight = CLLocationCoordinate2DMake(bottomLat!, rightLong!)
        bottomLeft  = CLLocationCoordinate2DMake(bottomLat!, leftLong!)
        topLeft     = CLLocationCoordinate2DMake(topLat!, leftLong!)
       
        let Newpath = GMSMutablePath()
        Newpath.add(topLeft!)
        Newpath.add(topRight!)
        Newpath.add(bottomRight!)
        Newpath.add(bottomLeft!)
        Newpath.add(topLeft!)
                 
        let Newpolyline = GMSPolyline(path: Newpath)
        Newpolyline.strokeWidth = 5.0;
        Newpolyline.strokeColor = .darkGray
        Newpolyline.map = self.MapView;
        
    }
    func mapView(_ mapView: GMSMapView, didChange position: GMSCameraPosition) {
       
        currentPosition!.position = position.target
                
        print(position.target.latitude)
        print(position.target.longitude)
       
        if position.target.latitude > topLat! {
            let goBackCamera = GMSCameraPosition.camera(withLatitude: topLat!, longitude: position.target.longitude, zoom: position.zoom)
            mapView.animate(to: goBackCamera)
        }
        if position.target.latitude < bottomLat! {
            let goBackCamera = GMSCameraPosition.camera(withLatitude: bottomLat!, longitude: position.target.longitude, zoom: position.zoom)
            mapView.animate(to: goBackCamera)
        }
        if position.target.longitude > rightLong! {
            let goBackCamera = GMSCameraPosition.camera(withLatitude: position.target.latitude, longitude: rightLong!, zoom: position.zoom)
            mapView.animate(to: goBackCamera)
        }
        if position.target.longitude < leftLong! {
            let goBackCamera = GMSCameraPosition.camera(withLatitude: position.target.latitude, longitude: leftLong!, zoom: position.zoom)
            mapView.animate(to: goBackCamera)
        }
     }
}

